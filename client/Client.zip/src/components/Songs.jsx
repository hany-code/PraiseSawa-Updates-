import React from 'react'

const Songs = () => {
  return (
    <div>
      Songs
    </div>
  )
}

export default Songs
