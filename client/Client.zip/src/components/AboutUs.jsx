// import React from "react";
// import PlankImage from "../assets/images/PlankImage.svg";

// const PlankPage = () => {
//   return (
//     <div className="flex flex-col items-center justify-center min-h-screen text-gray-800 px-4">
//       <img
//         src={PlankImage}
//         alt="Under Construction"
//         className="w-3/4 max-w-md md:w-1/2 lg:w-1/3"
//       />
//       <h1 className="text-2xl md:text-4xl font-bold mt-8">about us</h1>
//       <p className="text-base md:text-lg text-gray-600 mt-4 text-center max-w-xl">
//         We're still working on this feature. Stay tuned for updates!
//       </p>
//     </div>
//   );
// };

// export default PlankPage;
