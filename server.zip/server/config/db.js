const mongoose = require('mongoose');
const url = process.env.MONGODB_URI;

console.log('MongoDB URI:', url); // Add this line to see if the URL is defined

const connectDB = async () => {
  try {
    await mongoose.connect(url, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB connected...');
  } catch (err) {
    console.error('MongoDB connection error:', err.message);
    process.exit(1);
  }
};
module.exports = connectDB;
